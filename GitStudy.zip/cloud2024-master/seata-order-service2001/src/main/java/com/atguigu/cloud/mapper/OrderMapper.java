package com.atguigu.cloud.mapper;

import com.atguigu.cloud.entities.Order;
import tk.mybatis.mapper.common.Mapper;

public interface OrderMapper extends Mapper<Order> {
}